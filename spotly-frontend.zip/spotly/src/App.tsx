import React, { useState, useEffect, useCallback } from 'react'
import { apiGet } from './api'
import { getSavedLocation } from './utils'
import HomeView     from './views/HomeView'
import SearchView   from './views/SearchView'
import NearbyView   from './views/NearbyView'
import RegisterView from './views/RegisterView'
import AboutView    from './views/AboutView'
import ProfileView  from './views/ProfileView'
import type { View, Provider, LocationData } from './types'

// Bottom nav items
const NAV = [
  { id: 'home',     icon: 'ti-home',       label: 'Home'     },
  { id: 'search',   icon: 'ti-search',     label: 'Search'   },
  { id: 'nearby',   icon: 'ti-map-pin',    label: 'Nearby'   },
  { id: 'register', icon: 'ti-user-plus',  label: 'Register' },
  { id: 'about',    icon: 'ti-info-circle',label: 'About'    },
] as const

export default function App() {
  const [view,           setView]           = useState<View>('home')
  const [prevView,       setPrevView]       = useState<View>('home')
  const [searchQuery,    setSearchQuery]    = useState('')
  const [searchCategory, setSearchCategory] = useState('')
  const [profileTarget,  setProfileTarget]  = useState<Provider | null>(null)
  const [gpsCoords,      setGpsCoords]      = useState<{ lat: number; lon: number } | null>(null)
  const [currentTown,    setCurrentTown]    = useState(getSavedLocation().town)

  // Request GPS on mount — store in memory only, not localStorage
  useEffect(() => {
    requestGps()
  }, [])

  function requestGps() {
    if (!navigator.geolocation) return
    navigator.geolocation.getCurrentPosition(
      pos => {
        const coords = { lat: pos.coords.latitude, lon: pos.coords.longitude }
        setGpsCoords(coords)
        // Detect town from coordinates
        apiGet<any>('detectUserLocation', {
          town:  getSavedLocation().town,
          lga:   getSavedLocation().lga,
          state: getSavedLocation().state,
        }).then(d => {
          if (d?.town) setCurrentTown(d.town)
        }).catch(() => {})
      },
      () => {} // denied — handled per-view
    )
  }

  function navigate(v: View) {
    setPrevView(view)
    setView(v)
  }

  function goSearch(query: string, category?: string) {
    setSearchQuery(query)
    setSearchCategory(category || '')
    navigate('search')
  }

  function goProfile(provider: Provider) {
    setProfileTarget(provider)
    setPrevView(view)
    navigate('profile')
  }

  function goBack() {
    setView(prevView)
    setProfileTarget(null)
  }

  const isNavView = (v: View): v is 'home' | 'search' | 'nearby' | 'register' | 'about' =>
    ['home', 'search', 'nearby', 'register', 'about'].includes(v)

  return (
    <div className="max-w-md mx-auto bg-[#F7F6F3] min-h-screen flex flex-col relative">
      {/* Main content */}
      <div className="flex-1 overflow-hidden flex flex-col">
        {view === 'home' && (
          <div className="flex-1 overflow-y-auto">
            <HomeView
              onSearch={goSearch}
              onProfile={goProfile}
              gpsCoords={gpsCoords}
            />
          </div>
        )}

        {view === 'search' && (
          <div className="flex-1 overflow-hidden flex flex-col">
            <SearchView
              onProfile={goProfile}
              initialQuery={searchQuery}
              initialCategory={searchCategory}
              gpsCoords={gpsCoords}
            />
          </div>
        )}

        {view === 'nearby' && (
          <div className="flex-1 overflow-hidden flex flex-col">
            <NearbyView
              onProfile={goProfile}
              gpsCoords={gpsCoords}
              onRequestGps={requestGps}
              onSearchByTown={() => navigate('search')}
              currentTown={currentTown}
            />
          </div>
        )}

        {view === 'register' && (
          <div className="flex-1 overflow-y-auto">
            <RegisterView onHome={() => navigate('home')} />
          </div>
        )}

        {view === 'about' && (
          <div className="flex-1 overflow-y-auto">
            <AboutView />
          </div>
        )}

        {view === 'profile' && profileTarget && (
          <div className="flex-1 overflow-hidden flex flex-col">
            <ProfileView provider={profileTarget} onBack={goBack} />
          </div>
        )}
      </div>

      {/* Bottom navigation — always visible */}
      <nav
        className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white border-t border-[#EBEBEB] z-40 flex"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        {NAV.map(item => {
          const active = view === item.id
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.id === 'search') {
                  setSearchQuery('')
                  setSearchCategory('')
                }
                navigate(item.id as View)
              }}
              className="flex-1 flex flex-col items-center justify-center py-2 gap-0.5 transition-colors"
            >
              <i
                className={`ti ${item.icon} text-[22px]`}
                style={{ color: active ? '#0F6E56' : '#9E9E9E' }}
              />
              <span
                className="text-[10px] font-medium"
                style={{ color: active ? '#0F6E56' : '#9E9E9E' }}
              >
                {item.label}
              </span>
            </button>
          )
        })}
      </nav>
    </div>
  )
}
