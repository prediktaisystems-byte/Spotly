import React, { useState, useEffect } from 'react'
import { apiGet } from '../api'
import { getSavedLocation, getAvatarColor, getInitials } from '../utils'
import { SkeletonCard, ProviderCard, SectionHeader, EmptyState, ErrorState } from '../components/UI'
import LocationPicker from '../components/LocationPicker'
import type { Provider, Category, DashboardStats, LocationData } from '../types'

interface Props {
  onSearch: (query: string, category?: string) => void
  onProfile: (provider: Provider) => void
  gpsCoords: { lat: number; lon: number } | null
}

export default function HomeView({ onSearch, onProfile, gpsCoords }: Props) {
  const [stats,        setStats]        = useState<DashboardStats | null>(null)
  const [categories,   setCategories]   = useState<Category[]>([])
  const [featured,     setFeatured]     = useState<Provider[]>([])
  const [recent,       setRecent]       = useState<Provider[]>([])
  const [loading,      setLoading]      = useState(true)
  const [error,        setError]        = useState(false)
  const [searchText,   setSearchText]   = useState('')
  const [showPicker,   setShowPicker]   = useState(false)
  const [location,     setLocation]     = useState<LocationData>(getSavedLocation())

  const QUICK_CATS = [
    { name: 'Builder',       icon: 'ti-building' },
    { name: 'Mechanic',      icon: 'ti-car' },
    { name: 'Tailor',        icon: 'ti-scissors' },
    { name: 'Electrician',   icon: 'ti-bolt' },
    { name: 'Photographer',  icon: 'ti-camera' },
    { name: 'Caterer',       icon: 'ti-tools-kitchen' },
    { name: 'Plumber',       icon: 'ti-droplet' },
    { name: 'More',          icon: 'ti-grid-dots' },
  ]

  async function loadData(loc: LocationData) {
    setLoading(true)
    setError(false)
    try {
      const [s, c, f, dash] = await Promise.all([
        apiGet<DashboardStats>('getDashboardStats'),
        apiGet<Category[]>('getCategories'),
        loc.town ? apiGet<Provider[]>('getFeaturedProviders', { town: loc.town }) : Promise.resolve([]),
        loc.town ? apiGet<any>('getLocationDashboard', { town: loc.town, lga: loc.lga, state: loc.state }) : Promise.resolve(null),
      ])
      setStats(s)
      setCategories(c)
      setFeatured(f)
      setRecent(dash?.recentProviders || [])
    } catch {
      setError(true)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData(location)
    // Show picker if no location saved
    if (!location.town) setShowPicker(true)
  }, [])

  function handleLocationConfirm(loc: LocationData) {
    setLocation(loc)
    loadData(loc)
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault()
    onSearch(searchText)
  }

  const townLabel = location.town
    ? `${location.town}${location.lga ? ', ' + location.lga : ''}`
    : 'Set your location'

  return (
    <div className="pb-safe">
      {/* Hero */}
      <div className="bg-[#0F6E56] px-5 pt-12 pb-6" style={{ borderRadius: '0 0 24px 24px' }}>
        <div className="flex items-center justify-between mb-1">
          <span className="text-white text-[24px] font-medium tracking-tight">Spotly</span>
          <button
            onClick={() => setShowPicker(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-[20px] bg-white/10"
          >
            <i className="ti ti-map-pin text-[#9FE1CB] text-[13px]" />
            <span className="text-[12px] text-[#9FE1CB] font-medium max-w-[140px] truncate">{townLabel}</span>
          </button>
        </div>
        <p className="text-[#9FE1CB] text-[13px] mb-4">Find skilled workers near you</p>

        {/* Search bar */}
        <form onSubmit={handleSearch}>
          <div className="flex items-center gap-3 bg-white rounded-[24px] px-4 h-12">
            <i className="ti ti-search text-[#9E9E9E] text-[18px]" />
            <input
              type="text"
              value={searchText}
              onChange={e => setSearchText(e.target.value)}
              placeholder="Carpenter, mechanic, tailor..."
              className="flex-1 text-[14px] text-[#111111] placeholder:text-[#9E9E9E] bg-transparent outline-none"
            />
            {searchText && (
              <button type="submit" className="text-[#0F6E56] text-[13px] font-medium">
                Search
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="px-5 pt-5 space-y-6">
        {/* Category grid */}
        <div>
          <SectionHeader title="Browse by category" />
          <div className="grid grid-cols-4 gap-3">
            {QUICK_CATS.map(cat => (
              <button
                key={cat.name}
                onClick={() => cat.name === 'More' ? onSearch('') : onSearch('', cat.name)}
                className="flex flex-col items-center gap-1.5 bg-white border border-[#EBEBEB] rounded-[14px] py-3 px-1 transition-all hover:border-[#1D9E75] active:scale-95"
              >
                <i className={`ti ${cat.icon} text-[22px] text-[#1D9E75]`} />
                <span className="text-[11px] text-[#6B6B6B] leading-tight text-center">{cat.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Stats ribbon */}
        {stats && (
          <div className="bg-white border border-[#EBEBEB] rounded-[14px] p-4">
            <div className="grid grid-cols-3 divide-x divide-[#EBEBEB]">
              <div className="text-center px-2">
                <p className="text-[18px] font-medium text-[#0F6E56]">{stats.totalProviders}</p>
                <p className="text-[11px] text-[#9E9E9E] mt-0.5">Providers</p>
              </div>
              <div className="text-center px-2">
                <p className="text-[18px] font-medium text-[#0F6E56]">
                  {Object.keys(stats.providersByTown || {}).length}
                </p>
                <p className="text-[11px] text-[#9E9E9E] mt-0.5">Towns</p>
              </div>
              <div className="text-center px-2">
                <p className="text-[18px] font-medium text-[#0F6E56]">
                  {Object.keys(stats.providersByCategory || {}).length}
                </p>
                <p className="text-[11px] text-[#9E9E9E] mt-0.5">Occupations</p>
              </div>
            </div>
          </div>
        )}

        {/* Featured near you */}
        {location.town && (
          <div>
            <SectionHeader
              title="Featured near you"
              action={{ label: 'See all', onClick: () => onSearch('') }}
            />
            {loading ? (
              <div className="space-y-3">
                <SkeletonCard /><SkeletonCard />
              </div>
            ) : error ? (
              <ErrorState onRetry={() => loadData(location)} />
            ) : featured.length === 0 ? (
              <EmptyState
                icon="ti-star"
                title="No featured providers yet"
                subtitle={`Be the first featured provider in ${location.town}`}
              />
            ) : (
              <div className="space-y-3">
                {featured.slice(0, 5).map(p => (
                  <ProviderCard key={p.ProviderId} provider={p} onClick={() => onProfile(p)} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Recently joined */}
        {recent.length > 0 && (
          <div>
            <SectionHeader
              title="Recently joined"
              action={{ label: 'See all', onClick: () => onSearch('') }}
            />
            <div className="space-y-3">
              {recent.slice(0, 4).map(p => (
                <ProviderCard key={p.ProviderId} provider={p} onClick={() => onProfile(p)} />
              ))}
            </div>
          </div>
        )}

        {/* No location set */}
        {!location.town && !loading && (
          <EmptyState
            icon="ti-map-pin"
            title="Set your location"
            subtitle="Choose your town to see providers near you"
            action={{ label: 'Set location', onClick: () => setShowPicker(true) }}
          />
        )}
      </div>

      <LocationPicker
        open={showPicker}
        onClose={() => setShowPicker(false)}
        onConfirm={handleLocationConfirm}
        initial={location}
      />
    </div>
  )
}
