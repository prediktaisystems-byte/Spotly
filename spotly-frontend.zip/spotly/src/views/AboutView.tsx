import React, { useState, useEffect } from 'react'
import { apiGet } from '../api'
import type { DashboardStats } from '../types'

export default function AboutView() {
  const [stats, setStats] = useState<DashboardStats | null>(null)

  useEffect(() => {
    apiGet<DashboardStats>('getDashboardStats').then(setStats).catch(() => {})
  }, [])

  const infoCards = [
    {
      icon: 'ti-target',
      title: 'Our mission',
      body: 'Every skilled person deserves to be found. Spotly gives workers and businesses in every town a professional digital presence so customers can find them from anywhere at any time.',
    },
    {
      icon: 'ti-users',
      title: 'Who it is for',
      body: 'Carpenters, mechanics, tailors, electricians, plumbers, caterers, photographers, farmers, doctors, barbers, bakers, event planners and anyone offering a skill or service.',
    },
    {
      icon: 'ti-shield-check',
      title: 'Trust and verification',
      body: 'Every provider is manually verified before receiving a badge. Customer reviews are approved before going live. Ratings come from real people who used the service.',
    },
    {
      icon: 'ti-world',
      title: 'Growing across Africa',
      body: 'Started in Kwoi, Jaba LGA, Kaduna State. Now expanding across Nigeria and beyond. Every new town that joins adds more discoverable local talent to the network.',
    },
  ]

  return (
    <div className="px-5 pb-safe pt-5 space-y-5">
      {/* Hero card */}
      <div className="bg-[#0F6E56] rounded-[14px] p-5">
        <h1 className="text-white text-[20px] font-medium leading-snug mb-2">
          Making local skills discoverable
        </h1>
        <p className="text-[#9FE1CB] text-[13px] leading-relaxed">
          Spotly connects skilled workers and local businesses with customers in their communities.
          No apps to download. No accounts to create. Just search and connect.
        </p>
      </div>

      {/* Live stats */}
      {stats && (
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'Total providers', value: stats.totalProviders },
            { label: 'Towns covered', value: Object.keys(stats.providersByTown || {}).length },
            { label: 'Occupations', value: Object.keys(stats.providersByCategory || {}).length },
            { label: 'Reviews approved', value: stats.totalReviews },
          ].map(s => (
            <div key={s.label} className="bg-white border border-[#EBEBEB] rounded-[14px] p-4">
              <p className="text-[22px] font-medium text-[#0F6E56]">{s.value}</p>
              <p className="text-[11px] text-[#6B6B6B] mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Info cards */}
      {infoCards.map(card => (
        <div key={card.title} className="bg-white border border-[#EBEBEB] rounded-[14px] p-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 rounded-full bg-[#E8F5F0] flex items-center justify-center flex-shrink-0">
              <i className={`ti ${card.icon} text-[#0F6E56] text-[16px]`} />
            </div>
            <h3 className="text-[15px] font-medium text-[#111111]">{card.title}</h3>
          </div>
          <p className="text-[13px] text-[#6B6B6B] leading-relaxed">{card.body}</p>
        </div>
      ))}

      {/* Footer */}
      <p className="text-center text-[11px] text-[#9E9E9E] pb-4">
        Spotly · Built for local communities
      </p>
    </div>
  )
}
