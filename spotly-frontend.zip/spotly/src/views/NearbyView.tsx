import React, { useState, useEffect } from 'react'
import { apiGet } from '../api'
import { SkeletonCard, ProviderCard, EmptyState, ErrorState } from '../components/UI'
import type { Provider, Category } from '../types'

interface Props {
  onProfile: (provider: Provider) => void
  gpsCoords: { lat: number; lon: number } | null
  onRequestGps: () => void
  onSearchByTown: () => void
  currentTown: string
}

const RADII = [5, 10, 25, 50]

export default function NearbyView({ onProfile, gpsCoords, onRequestGps, onSearchByTown, currentTown }: Props) {
  const [results,    setResults]    = useState<Provider[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [activecat,  setActiveCat]  = useState('')
  const [radius,     setRadius]     = useState(10)
  const [loading,    setLoading]    = useState(false)
  const [error,      setError]      = useState(false)

  useEffect(() => {
    apiGet<Category[]>('getCategories').then(setCategories).catch(() => {})
  }, [])

  useEffect(() => {
    if (gpsCoords) runSearch()
  }, [gpsCoords, radius, activecat])

  async function runSearch() {
    if (!gpsCoords) return
    setLoading(true)
    setError(false)
    try {
      const data = await apiGet<Provider[]>('getNearbyProviders', {
        customerLat: gpsCoords.lat,
        customerLon: gpsCoords.lon,
        radiusKm:    radius,
        category:    activecat,
      })
      setResults(data)
    } catch {
      setError(true)
    } finally {
      setLoading(false)
    }
  }

  // No GPS — show enable prompt
  if (!gpsCoords) {
    return (
      <div className="flex flex-col items-center justify-center h-full px-8 text-center pb-safe">
        <div className="w-16 h-16 rounded-full bg-[#E8F5F0] flex items-center justify-center mb-5">
          <i className="ti ti-map-pin text-3xl text-[#0F6E56]" />
        </div>
        <p className="text-[15px] font-medium text-[#111111] mb-2">Enable location</p>
        <p className="text-[13px] text-[#6B6B6B] mb-6 leading-relaxed">
          Allow location access to find skilled workers near you
        </p>
        <button
          onClick={onRequestGps}
          className="w-full max-w-xs h-12 bg-[#0F6E56] text-white text-[14px] font-medium rounded-[10px] mb-3"
        >
          Enable location
        </button>
        <button
          onClick={onSearchByTown}
          className="w-full max-w-xs h-12 border border-[#EBEBEB] bg-white text-[14px] text-[#6B6B6B] font-medium rounded-[10px]"
        >
          Browse by town instead
        </button>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="sticky top-0 bg-[#F7F6F3] z-10 px-5 pt-4 pb-3 border-b border-[#EBEBEB]">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-[17px] font-medium text-[#111111]">Near you</h2>
            <p className="text-[12px] text-[#9E9E9E]">
              {currentTown || `${gpsCoords.lat.toFixed(3)}, ${gpsCoords.lon.toFixed(3)}`}
            </p>
          </div>
        </div>

        {/* Radius pills */}
        <div className="flex gap-2 mb-3">
          {RADII.map(r => (
            <button
              key={r}
              onClick={() => setRadius(r)}
              className={`flex-1 h-9 rounded-[20px] text-[13px] font-medium transition-colors ${
                radius === r
                  ? 'bg-[#0F6E56] text-white'
                  : 'bg-white text-[#6B6B6B] border border-[#EBEBEB]'
              }`}
            >
              {r}km
            </button>
          ))}
        </div>

        {/* Category chips */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          <button
            onClick={() => setActiveCat('')}
            className={`flex-shrink-0 px-3 py-1.5 rounded-[20px] text-[13px] font-medium transition-colors ${
              activecat === '' ? 'bg-[#0F6E56] text-white' : 'bg-white text-[#6B6B6B] border border-[#EBEBEB]'
            }`}
          >
            All
          </button>
          {categories.map(c => (
            <button
              key={c.CategoryId}
              onClick={() => setActiveCat(activecat === c.CategoryName ? '' : c.CategoryName)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-[20px] text-[13px] font-medium transition-colors ${
                activecat === c.CategoryName ? 'bg-[#0F6E56] text-white' : 'bg-white text-[#6B6B6B] border border-[#EBEBEB]'
              }`}
            >
              {c.CategoryName}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto px-5 py-4 pb-safe space-y-3">
        {loading ? (
          <><SkeletonCard /><SkeletonCard /><SkeletonCard /></>
        ) : error ? (
          <ErrorState onRetry={runSearch} />
        ) : results.length === 0 ? (
          <EmptyState
            icon="ti-map-pin"
            title={`No providers within ${radius}km`}
            subtitle="Try increasing the radius"
          />
        ) : (
          <>
            <p className="text-[13px] text-[#6B6B6B]">
              Showing {results.length} provider{results.length !== 1 ? 's' : ''} within {radius}km
            </p>
            {results.map(p => (
              <ProviderCard key={p.ProviderId} provider={p} onClick={() => onProfile(p)} />
            ))}
          </>
        )}
      </div>
    </div>
  )
}
