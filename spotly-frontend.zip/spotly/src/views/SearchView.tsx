import React, { useState, useEffect, useRef } from 'react'
import { apiGet } from '../api'
import { getSavedLocation } from '../utils'
import { SkeletonCard, ProviderCard, EmptyState, ErrorState, BottomSheet, SelectInput, PrimaryButton } from '../components/UI'
import type { Provider, Category, StateItem, LgaItem, TownItem } from '../types'

interface Props {
  onProfile: (provider: Provider) => void
  initialQuery?: string
  initialCategory?: string
  gpsCoords: { lat: number; lon: number } | null
}

export default function SearchView({ onProfile, initialQuery = '', initialCategory = '', gpsCoords }: Props) {
  const [query,      setQuery]      = useState(initialQuery)
  const [results,    setResults]    = useState<Provider[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading,    setLoading]    = useState(false)
  const [error,      setError]      = useState(false)
  const [activecat,  setActiveCat]  = useState(initialCategory)
  const [showFilter, setShowFilter] = useState(false)

  // Filter state
  const [filterState, setFilterState] = useState(getSavedLocation().state)
  const [filterLga,   setFilterLga]   = useState(getSavedLocation().lga)
  const [filterTown,  setFilterTown]  = useState(getSavedLocation().town)
  const [states,      setStates]      = useState<StateItem[]>([])
  const [lgas,        setLgas]        = useState<LgaItem[]>([])
  const [towns,       setTowns]       = useState<TownItem[]>([])

  const debounceRef = useRef<ReturnType<typeof setTimeout>>()

  // Load categories once
  useEffect(() => {
    apiGet<Category[]>('getCategories').then(setCategories).catch(() => {})
    apiGet<StateItem[]>('getStates').then(setStates).catch(() => {})
  }, [])

  // Load LGAs when filter state changes
  useEffect(() => {
    if (!filterState) { setLgas([]); return }
    apiGet<LgaItem[]>('getLgasByState', { state: filterState }).then(setLgas).catch(() => {})
    setFilterLga('')
    setFilterTown('')
  }, [filterState])

  // Load towns when filter LGA changes
  useEffect(() => {
    if (!filterLga) { setTowns([]); return }
    apiGet<TownItem[]>('getTownsByLga', { lga: filterLga, state: filterState }).then(setTowns).catch(() => {})
    setFilterTown('')
  }, [filterLga])

  // Run search whenever query, category or location filters change
  useEffect(() => {
    clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => runSearch(), 400)
    return () => clearTimeout(debounceRef.current)
  }, [query, activecat, filterTown, filterLga, filterState])

  async function runSearch() {
    setLoading(true)
    setError(false)
    try {
      const data = await apiGet<Provider[]>('searchProviders', {
        query,
        category:    activecat,
        town:        filterTown,
        lga:         filterLga,
        state:       filterState,
        customerLat: gpsCoords?.lat,
        customerLon: gpsCoords?.lon,
      })
      setResults(data)
    } catch {
      setError(true)
    } finally {
      setLoading(false)
    }
  }

  function applyFilter() {
    setShowFilter(false)
    runSearch()
  }

  function resetFilter() {
    setFilterState('')
    setFilterLga('')
    setFilterTown('')
  }

  return (
    <div className="flex flex-col h-full">
      {/* Sticky search header */}
      <div className="sticky top-0 bg-[#F7F6F3] z-10 px-5 pt-4 pb-3 border-b border-[#EBEBEB]">
        <div className="flex gap-2">
          <div className="flex-1 flex items-center gap-2 bg-white border border-[#EBEBEB] rounded-[8px] px-3 h-11">
            <i className="ti ti-search text-[#9E9E9E] text-[16px]" />
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search providers..."
              autoFocus
              className="flex-1 text-[14px] text-[#111111] placeholder:text-[#9E9E9E] bg-transparent outline-none"
            />
            {query && (
              <button onClick={() => setQuery('')}>
                <i className="ti ti-x text-[#9E9E9E] text-[14px]" />
              </button>
            )}
          </div>
          <button
            onClick={() => setShowFilter(true)}
            className="h-11 w-11 flex items-center justify-center bg-white border border-[#EBEBEB] rounded-[8px] flex-shrink-0"
          >
            <i className="ti ti-adjustments-horizontal text-[#111111] text-[18px]" />
          </button>
        </div>

        {/* Category chips */}
        <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar pb-1">
          <button
            onClick={() => setActiveCat('')}
            className={`flex-shrink-0 px-3 py-1.5 rounded-[20px] text-[13px] font-medium transition-colors ${
              activecat === ''
                ? 'bg-[#0F6E56] text-white'
                : 'bg-white text-[#6B6B6B] border border-[#EBEBEB]'
            }`}
          >
            All
          </button>
          {categories.map(c => (
            <button
              key={c.CategoryId}
              onClick={() => setActiveCat(activecat === c.CategoryName ? '' : c.CategoryName)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-[20px] text-[13px] font-medium transition-colors ${
                activecat === c.CategoryName
                  ? 'bg-[#0F6E56] text-white'
                  : 'bg-white text-[#6B6B6B] border border-[#EBEBEB]'
              }`}
            >
              {c.CategoryName}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto px-5 py-4 pb-safe space-y-3">
        {/* Active filters indicator */}
        {(filterTown || filterLga || filterState) && (
          <div className="flex items-center gap-2 flex-wrap">
            {filterState && (
              <span className="flex items-center gap-1 px-2 py-1 bg-[#E8F5F0] text-[#085041] rounded-[20px] text-[12px]">
                <i className="ti ti-map-pin text-[11px]" />
                {filterState}
                <button onClick={() => { setFilterState(''); setFilterLga(''); setFilterTown('') }}>
                  <i className="ti ti-x text-[11px]" />
                </button>
              </span>
            )}
            {filterLga && (
              <span className="flex items-center gap-1 px-2 py-1 bg-[#E8F5F0] text-[#085041] rounded-[20px] text-[12px]">
                {filterLga}
                <button onClick={() => { setFilterLga(''); setFilterTown('') }}>
                  <i className="ti ti-x text-[11px]" />
                </button>
              </span>
            )}
            {filterTown && (
              <span className="flex items-center gap-1 px-2 py-1 bg-[#E8F5F0] text-[#085041] rounded-[20px] text-[12px]">
                {filterTown}
                <button onClick={() => setFilterTown('')}>
                  <i className="ti ti-x text-[11px]" />
                </button>
              </span>
            )}
          </div>
        )}

        {loading ? (
          <>
            <SkeletonCard /><SkeletonCard /><SkeletonCard />
          </>
        ) : error ? (
          <ErrorState onRetry={runSearch} />
        ) : results.length === 0 ? (
          <EmptyState
            icon="ti-search"
            title="No providers found"
            subtitle="Try a different search or location"
          />
        ) : (
          <>
            <p className="text-[13px] text-[#6B6B6B]">{results.length} provider{results.length !== 1 ? 's' : ''} found</p>
            {results.map(p => (
              <ProviderCard key={p.ProviderId} provider={p} onClick={() => onProfile(p)} />
            ))}
          </>
        )}
      </div>

      {/* Filter bottom sheet */}
      <BottomSheet open={showFilter} onClose={() => setShowFilter(false)} title="Filter providers">
        <div className="space-y-3">
          <div>
            <p className="text-[12px] text-[#9E9E9E] mb-1.5 font-medium uppercase tracking-wide">State</p>
            <SelectInput
              value={filterState}
              onChange={setFilterState}
              placeholder="Any state"
              options={states.map(s => ({ value: s.state, label: s.state }))}
            />
          </div>
          {filterState && (
            <div>
              <p className="text-[12px] text-[#9E9E9E] mb-1.5 font-medium uppercase tracking-wide">LGA</p>
              <SelectInput
                value={filterLga}
                onChange={setFilterLga}
                placeholder="Any LGA"
                options={lgas.map(l => ({ value: l.lga, label: l.lga }))}
              />
            </div>
          )}
          {filterLga && (
            <div>
              <p className="text-[12px] text-[#9E9E9E] mb-1.5 font-medium uppercase tracking-wide">Town</p>
              <SelectInput
                value={filterTown}
                onChange={setFilterTown}
                placeholder="Any town"
                options={towns.map(t => ({ value: t.town, label: t.town }))}
              />
            </div>
          )}
          <div className="flex gap-3 pt-2">
            <button
              onClick={resetFilter}
              className="flex-1 h-11 border border-[#EBEBEB] rounded-[10px] text-[14px] text-[#6B6B6B] font-medium"
            >
              Reset
            </button>
            <button
              onClick={applyFilter}
              className="flex-1 h-11 bg-[#0F6E56] rounded-[10px] text-[14px] text-white font-medium"
            >
              Apply
            </button>
          </div>
        </div>
      </BottomSheet>
    </div>
  )
}
