import React, { useState, useEffect, useRef } from 'react'
import { apiGet, apiPost } from '../api'
import { getAvatarColor, getInitials, formatWhatsApp, renderStarsArray, relativeDate } from '../utils'
import { Stars, SkeletonCard } from '../components/UI'
import type { Provider, Review } from '../types'

interface Props {
  provider: Provider
  onBack: () => void
}

type Tab = 'info' | 'portfolio' | 'reviews'

export default function ProfileView({ provider: initialProvider, onBack }: Props) {
  const [provider,  setProvider]  = useState<Provider>(initialProvider)
  const [reviews,   setReviews]   = useState<Review[]>([])
  const [tab,       setTab]       = useState<Tab>('info')
  const [loading,   setLoading]   = useState(false)

  // Review form
  const [rName,     setRName]     = useState('')
  const [rRating,   setRRating]   = useState(0)
  const [rText,     setRText]     = useState('')
  const [rLoading,  setRLoading]  = useState(false)
  const [rSuccess,  setRSuccess]  = useState(false)
  const [rError,    setRError]    = useState('')

  // Portfolio upload
  const fileRef  = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [upError,   setUpError]   = useState('')

  const isPremium  = provider.PlanType === 'premium'
  const isVerified = provider.Verified === 'true'
  const imgLimit   = isPremium ? 5 : 3
  const urls       = Array.isArray(provider.PortfolioUrls) ? provider.PortfolioUrls : []

  useEffect(() => {
    loadReviews()
  }, [])

  async function loadReviews() {
    try {
      const data = await apiGet<Review[]>('getProviderReviews', { providerId: provider.ProviderId })
      setReviews(data)
    } catch {}
  }

  async function submitReview() {
    if (!rName || rRating === 0) return
    setRLoading(true)
    setRError('')
    try {
      await apiPost({
        action: 'submitReview',
        providerId: provider.ProviderId,
        reviewerName: rName,
        rating: rRating,
        reviewText: rText,
      })
      setRSuccess(true)
    } catch (e: any) {
      setRError(e.message)
    } finally {
      setRLoading(false)
    }
  }

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setUpError('')

    // Size check
    if (file.size > 2097152) {
      setUpError('Image too large — max 2MB. Compress and try again.')
      return
    }
    // Type check
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
    if (!allowed.includes(file.type)) {
      setUpError('Only JPEG, PNG and WebP images are accepted.')
      return
    }

    setUploading(true)
    try {
      // Convert to base64
      const base64Data = await new Promise<string>((res, rej) => {
        const r = new FileReader()
        r.onload  = () => res((r.result as string).split(',')[1])
        r.onerror = rej
        r.readAsDataURL(file)
      })

      const result = await apiPost<{ imageUrl: string; remainingSlots: number }>({
        action:    'uploadPortfolioImage',
        providerId: provider.ProviderId,
        base64Data,
        mimeType:  file.type,
        fileName:  file.name,
      })

      // Update portfolio URLs in state
      setProvider(p => ({
        ...p,
        PortfolioUrls: [...urls, result.imageUrl],
      }))
    } catch (e: any) {
      setUpError(e.message || 'Upload failed')
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  async function deleteImage(url: string) {
    // Extract file ID from Google Drive URL
    const match = url.match(/id=([^&]+)/)
    if (!match) return
    const fileId = match[1]
    try {
      await apiPost({
        action: 'deletePortfolioImage',
        providerId: provider.ProviderId,
        fileId,
      })
      setProvider(p => ({
        ...p,
        PortfolioUrls: urls.filter(u => u !== url),
      }))
    } catch {}
  }

  const { bg, text } = getAvatarColor(provider.FullName)
  const initials = getInitials(provider.FullName)
  const waLink = formatWhatsApp(provider.WhatsApp || provider.Phone, provider.FullName)

  const TABS: { id: Tab; label: string }[] = [
    { id: 'info',      label: 'Info' },
    { id: 'portfolio', label: 'Portfolio' },
    { id: 'reviews',   label: `Reviews${reviews.length > 0 ? ` (${reviews.length})` : ''}` },
  ]

  return (
    <div className="flex flex-col h-full">
      {/* Top bar */}
      <div className="flex items-center gap-3 px-5 pt-4 pb-3 bg-[#F7F6F3] border-b border-[#EBEBEB]">
        <button onClick={onBack}>
          <i className="ti ti-arrow-left text-[20px] text-[#111111]" />
        </button>
        <span className="text-[15px] font-medium text-[#111111]">Profile</span>
      </div>

      <div className="flex-1 overflow-y-auto pb-[100px]">
        {/* Profile header */}
        <div className="px-5 pt-5 pb-4 border-b border-[#EBEBEB]">
          <div className="flex gap-4 items-start">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center text-[18px] font-medium flex-shrink-0"
              style={{ background: bg, color: text }}
            >
              {initials}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-[18px] font-medium text-[#111111]">{provider.FullName}</h1>
              <p className="text-[13px] text-[#6B6B6B]">
                {provider.Profession} · {provider.Town}
              </p>

              {/* Badges */}
              <div className="flex flex-wrap gap-1.5 mt-2">
                {isVerified && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-[20px] text-[11px] bg-[#E8F5F0] text-[#085041]">
                    <i className="ti ti-circle-check text-[11px]" /> Verified
                  </span>
                )}
                {isPremium && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-[20px] text-[11px] bg-[#FEF3DC] text-[#854F0B]">
                    <i className="ti ti-crown text-[11px]" /> Premium
                  </span>
                )}
                <span className="px-2 py-0.5 rounded-[20px] text-[11px] bg-[#F1EFE8] text-[#444441] font-mono">
                  {provider.ProviderId}
                </span>
              </div>

              {/* Rating */}
              {Number(provider.AverageRating) > 0 && (
                <div className="flex items-center gap-1.5 mt-2">
                  <Stars rating={provider.AverageRating} size={13} />
                  <span className="text-[13px] text-[#6B6B6B]">
                    {Number(provider.AverageRating).toFixed(1)} · {provider.TotalReviews} review{provider.TotalReviews !== 1 ? 's' : ''}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 divide-x divide-[#EBEBEB] mt-4 border border-[#EBEBEB] rounded-[14px] overflow-hidden">
            {[
              { label: 'Rating', value: Number(provider.AverageRating) > 0 ? Number(provider.AverageRating).toFixed(1) : '—' },
              { label: 'Reviews', value: provider.TotalReviews || 0 },
              { label: 'Yrs exp', value: provider.YearsExperience || 0 },
            ].map(s => (
              <div key={s.label} className="py-3 text-center">
                <p className="text-[16px] font-medium text-[#111111]">{s.value}</p>
                <p className="text-[11px] text-[#9E9E9E]">{s.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Tab bar */}
        <div className="flex border-b border-[#EBEBEB] bg-white px-5">
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex-1 py-3 text-[13px] font-medium transition-colors relative ${
                tab === t.id ? 'text-[#0F6E56]' : 'text-[#9E9E9E]'
              }`}
            >
              {t.label}
              {tab === t.id && (
                <div className="absolute bottom-0 left-1/4 right-1/4 h-[2px] bg-[#0F6E56] rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="px-5 py-4">
          {/* INFO TAB */}
          {tab === 'info' && (
            <div className="space-y-4">
              {provider.Bio && (
                <p className="text-[13px] text-[#6B6B6B] leading-relaxed">{provider.Bio}</p>
              )}
              <div className="space-y-3">
                {[
                  { icon: 'ti-map-pin',    label: `${provider.Town}, ${provider.LGA}, ${provider.State}` },
                  provider.distanceLabel && provider.distanceLabel !== 'Distance unknown'
                    ? { icon: 'ti-map-2',  label: provider.distanceLabel }
                    : null,
                  { icon: 'ti-clock',      label: `${provider.YearsExperience || 0} years experience` },
                  { icon: 'ti-id-badge',   label: provider.ProviderId },
                ].filter(Boolean).map((row: any) => (
                  <div key={row.icon} className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#F7F6F3] flex items-center justify-center flex-shrink-0">
                      <i className={`ti ${row.icon} text-[#6B6B6B] text-[14px]`} />
                    </div>
                    <p className="text-[13px] text-[#6B6B6B]">{row.label}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* PORTFOLIO TAB */}
          {tab === 'portfolio' && (
            <div>
              <p className="text-[12px] text-[#9E9E9E] mb-3">
                {urls.length} of {imgLimit} photo{imgLimit !== 1 ? 's' : ''} used
              </p>

              {upError && (
                <div className="mb-3 p-3 bg-red-50 border border-red-100 rounded-[8px]">
                  <p className="text-[13px] text-red-600">{upError}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                {urls.map((url, i) => (
                  <div key={i} className="relative aspect-square rounded-[8px] overflow-hidden bg-[#F7F6F3] group">
                    <img src={url} alt="" className="w-full h-full object-cover" />
                    <button
                      onClick={() => deleteImage(url)}
                      className="absolute top-1.5 right-1.5 w-7 h-7 bg-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <i className="ti ti-trash text-red-500 text-[14px]" />
                    </button>
                  </div>
                ))}

                {/* Add photo slot */}
                {urls.length < imgLimit && (
                  <button
                    onClick={() => fileRef.current?.click()}
                    disabled={uploading}
                    className="aspect-square rounded-[8px] border-2 border-dashed border-[#EBEBEB] flex flex-col items-center justify-center gap-1 hover:border-[#1D9E75] transition-colors"
                  >
                    {uploading ? (
                      <i className="ti ti-loader-2 animate-spin text-[#0F6E56] text-[22px]" />
                    ) : (
                      <>
                        <i className="ti ti-plus text-[#9E9E9E] text-[22px]" />
                        <span className="text-[11px] text-[#9E9E9E]">Add photo</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* Hidden file input */}
              <input
                ref={fileRef}
                type="file"
                accept="image/jpeg,image/jpg,image/png,image/webp"
                className="hidden"
                onChange={handleFileSelected}
              />
            </div>
          )}

          {/* REVIEWS TAB */}
          {tab === 'reviews' && (
            <div className="space-y-4">
              {/* Review list */}
              {reviews.length > 0 && (
                <div className="space-y-0 divide-y divide-[#EBEBEB]">
                  {reviews.map(r => (
                    <div key={r.ReviewId} className="py-3">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-[13px] font-medium text-[#111111]">{r.ReviewerName}</p>
                        <p className="text-[11px] text-[#9E9E9E]">{relativeDate(r.DateSubmitted)}</p>
                      </div>
                      <Stars rating={r.Rating} size={13} />
                      {r.ReviewText && (
                        <p className="text-[13px] text-[#6B6B6B] mt-1 leading-relaxed">{r.ReviewText}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Submit review form */}
              {!rSuccess ? (
                <div className="pt-2">
                  <h3 className="text-[14px] font-medium text-[#111111] mb-3">Leave a review</h3>
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={rName}
                      onChange={e => setRName(e.target.value)}
                      placeholder="Your name"
                      className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56]"
                    />

                    {/* Star selector */}
                    <div className="flex gap-2">
                      {[1,2,3,4,5].map(n => (
                        <button
                          key={n}
                          onClick={() => setRRating(n)}
                          className="p-1"
                        >
                          <i
                            className={`ti ti-star${n <= rRating ? '-filled' : ''} text-[28px]`}
                            style={{ color: n <= rRating ? '#D4930A' : '#EBEBEB' }}
                          />
                        </button>
                      ))}
                    </div>

                    <div>
                      <textarea
                        value={rText}
                        onChange={e => setRText(e.target.value.slice(0, 200))}
                        placeholder="How was the service? (optional)"
                        rows={3}
                        className="w-full px-3 py-2.5 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56] resize-none"
                      />
                      <p className="text-[11px] text-[#9E9E9E] text-right">{rText.length}/200</p>
                    </div>

                    {rError && (
                      <p className="text-[13px] text-red-500">{rError}</p>
                    )}

                    <button
                      onClick={submitReview}
                      disabled={!rName || rRating === 0 || rLoading}
                      className="w-full h-11 bg-[#0F6E56] text-white text-[14px] font-medium rounded-[10px] disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {rLoading && <i className="ti ti-loader-2 animate-spin text-[16px]" />}
                      Submit review
                    </button>
                  </div>
                </div>
              ) : (
                <div className="py-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-[#E8F5F0] flex items-center justify-center mx-auto mb-3">
                    <i className="ti ti-check text-[#0F6E56] text-[20px]" />
                  </div>
                  <p className="text-[14px] font-medium text-[#111111]">Thank you!</p>
                  <p className="text-[13px] text-[#6B6B6B] mt-1">Your review is pending approval</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Fixed action buttons */}
      <div className="fixed bottom-[64px] left-0 right-0 px-5 py-3 bg-[#F7F6F3] border-t border-[#EBEBEB] flex gap-3">
        <a
          href={`tel:${provider.Phone}`}
          className="flex-1 h-12 bg-[#0F6E56] text-white text-[14px] font-medium rounded-[10px] flex items-center justify-center gap-2"
        >
          <i className="ti ti-phone text-[16px]" />
          Call now
        </a>
        <a
          href={waLink}
          target="_blank"
          rel="noreferrer"
          className="flex-1 h-12 border-2 border-[#0F6E56] text-[#0F6E56] text-[14px] font-medium rounded-[10px] flex items-center justify-center gap-2"
        >
          <i className="ti ti-brand-whatsapp text-[16px]" />
          WhatsApp
        </a>
      </div>
    </div>
  )
}
