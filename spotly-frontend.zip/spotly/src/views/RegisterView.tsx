import React, { useState, useEffect } from 'react'
import { apiGet, apiPost } from '../api'
import { formatWhatsApp } from '../utils'
import { SelectInput, PrimaryButton } from '../components/UI'
import type { Category, StateItem, LgaItem, TownItem } from '../types'

interface Props {
  onHome: () => void
}

interface FormData {
  FullName: string
  Phone: string
  WhatsApp: string
  AgentId: string
  Category: string
  Profession: string
  YearsExperience: number
  Bio: string
  State: string
  LGA: string
  Town: string
  Latitude: string
  Longitude: string
}

const EMPTY: FormData = {
  FullName: '', Phone: '', WhatsApp: '', AgentId: '',
  Category: '', Profession: '', YearsExperience: 0, Bio: '',
  State: '', LGA: '', Town: '', Latitude: '', Longitude: '',
}

export default function RegisterView({ onHome }: Props) {
  const [step,       setStep]       = useState(1)
  const [form,       setForm]       = useState<FormData>(EMPTY)
  const [categories, setCategories] = useState<Category[]>([])
  const [states,     setStates]     = useState<StateItem[]>([])
  const [lgas,       setLgas]       = useState<LgaItem[]>([])
  const [towns,      setTowns]      = useState<TownItem[]>([])
  const [showAgent,  setShowAgent]  = useState(false)
  const [useCustomTown, setUseCustomTown] = useState(false)
  const [customTown, setCustomTown] = useState('')
  const [gpsStatus,  setGpsStatus]  = useState<'idle'|'loading'|'success'|'denied'>('idle')
  const [loading,    setLoading]    = useState(false)
  const [error,      setError]      = useState('')
  const [success,    setSuccess]    = useState<{ providerId: string } | null>(null)

  useEffect(() => {
    apiGet<Category[]>('getCategories').then(setCategories).catch(() => {})
    apiGet<StateItem[]>('getStates').then(setStates).catch(() => {})
  }, [])

  useEffect(() => {
    if (!form.State) { setLgas([]); return }
    apiGet<LgaItem[]>('getLgasByState', { state: form.State }).then(setLgas).catch(() => {})
    set('LGA', '')
    set('Town', '')
  }, [form.State])

  useEffect(() => {
    if (!form.LGA) { setTowns([]); return }
    apiGet<TownItem[]>('getTownsByLga', { lga: form.LGA, state: form.State }).then(setTowns).catch(() => {})
    set('Town', '')
  }, [form.LGA])

  function set<K extends keyof FormData>(key: K, value: FormData[K]) {
    setForm(f => ({ ...f, [key]: value }))
  }

  function captureGps() {
    setGpsStatus('loading')
    navigator.geolocation.getCurrentPosition(
      pos => {
        set('Latitude',  String(pos.coords.latitude))
        set('Longitude', String(pos.coords.longitude))
        setGpsStatus('success')
      },
      () => setGpsStatus('denied'),
      { timeout: 10000 }
    )
  }

  async function handleSubmit() {
    setLoading(true)
    setError('')
    try {
      const town = useCustomTown ? customTown : form.Town
      const data = await apiPost<{ providerId: string }>({
        action: 'registerProvider',
        data: { ...form, Town: town },
      })
      setSuccess(data)
    } catch (e: any) {
      setError(e.message || 'Registration failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // ── Success screen ────────────────────────────────────────────────────────
  if (success) {
    const waMsg = encodeURIComponent(
      `Find me on Spotly — search ${form.FullName} to contact me. spotly.ng`
    )
    return (
      <div className="flex flex-col items-center justify-center min-h-full px-6 pb-safe text-center">
        <div className="w-16 h-16 rounded-full bg-[#E8F5F0] flex items-center justify-center mb-5">
          <i className="ti ti-check text-3xl text-[#0F6E56]" />
        </div>
        <h2 className="text-[22px] font-medium text-[#111111] mb-2">You're on Spotly!</h2>
        <p className="text-[13px] text-[#6B6B6B] mb-5">
          Your profile is live. Customers in {form.Town} can now find you.
        </p>
        <div className="bg-[#0F6E56] px-5 py-2.5 rounded-[20px] mb-6">
          <span className="font-mono text-white text-[14px] font-medium tracking-wide">
            {success.providerId}
          </span>
        </div>
        <a
          href={`https://wa.me/?text=${waMsg}`}
          target="_blank"
          rel="noreferrer"
          className="w-full max-w-xs h-12 flex items-center justify-center gap-2 bg-[#25D366] text-white text-[14px] font-medium rounded-[10px] mb-3"
        >
          <i className="ti ti-brand-whatsapp text-[18px]" />
          Share on WhatsApp
        </a>
        <button
          onClick={onHome}
          className="w-full max-w-xs h-12 border border-[#EBEBEB] bg-white text-[14px] text-[#6B6B6B] font-medium rounded-[10px]"
        >
          Go home
        </button>
      </div>
    )
  }

  const progress = (step / 4) * 100

  return (
    <div className="flex flex-col h-full">
      {/* Progress bar */}
      <div className="h-[3px] bg-[#EBEBEB]">
        <div
          className="h-full bg-[#0F6E56] transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Step header */}
      <div className="flex items-center gap-3 px-5 pt-4 pb-3">
        {step > 1 && (
          <button onClick={() => setStep(s => s - 1)}>
            <i className="ti ti-arrow-left text-[20px] text-[#111111]" />
          </button>
        )}
        <p className="text-[12px] text-[#9E9E9E]">Step {step} of 4</p>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-safe">
        {/* ── STEP 1 ─────────────────────────────────────────────────────── */}
        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-[17px] font-medium text-[#111111]">Tell us about yourself</h2>

            <div>
              <label className="text-[12px] text-[#6B6B6B] mb-1 block">Full name *</label>
              <input
                type="text"
                value={form.FullName}
                onChange={e => set('FullName', e.target.value)}
                placeholder="Hassan Musa"
                className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56]"
              />
            </div>

            <div>
              <label className="text-[12px] text-[#6B6B6B] mb-1 block">Phone number *</label>
              <input
                type="tel"
                value={form.Phone}
                onChange={e => set('Phone', e.target.value)}
                placeholder="+234 800 000 0000"
                className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56]"
              />
            </div>

            <div>
              <label className="text-[12px] text-[#6B6B6B] mb-1 block">WhatsApp number (optional)</label>
              <input
                type="tel"
                value={form.WhatsApp}
                onChange={e => set('WhatsApp', e.target.value)}
                placeholder="Same as phone? Leave empty"
                className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56]"
              />
            </div>

            <button
              onClick={() => setShowAgent(!showAgent)}
              className="flex items-center gap-2 text-[13px] text-[#0F6E56] font-medium"
            >
              <i className={`ti ${showAgent ? 'ti-chevron-up' : 'ti-chevron-down'} text-[14px]`} />
              Registered by an agent?
            </button>

            {showAgent && (
              <div>
                <label className="text-[12px] text-[#6B6B6B] mb-1 block">Agent code</label>
                <input
                  type="text"
                  value={form.AgentId}
                  onChange={e => set('AgentId', e.target.value)}
                  placeholder="e.g. AGT-1001"
                  className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56]"
                />
              </div>
            )}

            <PrimaryButton
              onClick={() => setStep(2)}
              disabled={!form.FullName || !form.Phone}
            >
              Continue
            </PrimaryButton>
          </div>
        )}

        {/* ── STEP 2 ─────────────────────────────────────────────────────── */}
        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-[17px] font-medium text-[#111111]">What do you do?</h2>

            <div>
              <label className="text-[12px] text-[#6B6B6B] mb-1 block">Category</label>
              <SelectInput
                value={form.Category}
                onChange={v => set('Category', v)}
                placeholder="Select a category"
                options={categories.map(c => ({ value: c.CategoryName, label: c.CategoryName }))}
              />
            </div>

            <div>
              <label className="text-[12px] text-[#6B6B6B] mb-1 block">Profession *</label>
              <input
                type="text"
                value={form.Profession}
                onChange={e => set('Profession', e.target.value)}
                placeholder="e.g. Carpenter, Solar Panel Installer"
                className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56]"
              />
              <p className="text-[11px] text-[#9E9E9E] mt-1">
                Don't see your occupation? Type it — we'll add it automatically
              </p>
            </div>

            <div>
              <label className="text-[12px] text-[#6B6B6B] mb-1 block">Years of experience</label>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => set('YearsExperience', Math.max(0, form.YearsExperience - 1))}
                  className="w-10 h-10 rounded-full border border-[#EBEBEB] bg-white flex items-center justify-center text-[18px] text-[#111111]"
                >
                  −
                </button>
                <span className="text-[18px] font-medium text-[#111111] w-8 text-center">
                  {form.YearsExperience}
                </span>
                <button
                  onClick={() => set('YearsExperience', form.YearsExperience + 1)}
                  className="w-10 h-10 rounded-full border border-[#EBEBEB] bg-white flex items-center justify-center text-[18px] text-[#111111]"
                >
                  +
                </button>
              </div>
            </div>

            <div>
              <label className="text-[12px] text-[#6B6B6B] mb-1 block">About you (optional)</label>
              <textarea
                value={form.Bio}
                onChange={e => set('Bio', e.target.value.slice(0, 300))}
                placeholder="Briefly describe your skills and services..."
                rows={4}
                className="w-full px-3 py-2.5 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56] resize-none"
              />
              <p className="text-[11px] text-[#9E9E9E] text-right mt-0.5">{form.Bio.length}/300</p>
            </div>

            <PrimaryButton
              onClick={() => setStep(3)}
              disabled={!form.Profession}
            >
              Continue
            </PrimaryButton>
          </div>
        )}

        {/* ── STEP 3 ─────────────────────────────────────────────────────── */}
        {step === 3 && (
          <div className="space-y-4">
            <h2 className="text-[17px] font-medium text-[#111111]">Where are you based?</h2>

            <div>
              <label className="text-[12px] text-[#6B6B6B] mb-1 block">State *</label>
              <SelectInput
                value={form.State}
                onChange={v => set('State', v)}
                placeholder="Select state"
                options={states.map(s => ({ value: s.state, label: s.state }))}
              />
            </div>

            {form.State && (
              <div>
                <label className="text-[12px] text-[#6B6B6B] mb-1 block">LGA *</label>
                <SelectInput
                  value={form.LGA}
                  onChange={v => set('LGA', v)}
                  placeholder="Select LGA"
                  options={lgas.map(l => ({ value: l.lga, label: l.lga }))}
                />
              </div>
            )}

            {form.LGA && !useCustomTown && (
              <div>
                <label className="text-[12px] text-[#6B6B6B] mb-1 block">Town *</label>
                <SelectInput
                  value={form.Town}
                  onChange={v => set('Town', v)}
                  placeholder="Select town"
                  options={towns.map(t => ({ value: t.town, label: t.town }))}
                />
              </div>
            )}

            {form.LGA && useCustomTown && (
              <div>
                <label className="text-[12px] text-[#6B6B6B] mb-1 block">Town name *</label>
                <input
                  type="text"
                  value={customTown}
                  onChange={e => setCustomTown(e.target.value)}
                  placeholder="Type your town name"
                  className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] placeholder:text-[#9E9E9E] bg-white focus:outline-none focus:border-[#0F6E56]"
                />
              </div>
            )}

            {form.LGA && (
              <label className="flex items-center gap-2 text-[13px] text-[#6B6B6B] cursor-pointer">
                <input
                  type="checkbox"
                  checked={useCustomTown}
                  onChange={e => setUseCustomTown(e.target.checked)}
                  className="w-4 h-4 accent-[#0F6E56]"
                />
                My town isn't listed
              </label>
            )}

            {/* GPS capture */}
            <button
              onClick={captureGps}
              disabled={gpsStatus === 'loading'}
              className="w-full flex items-center gap-3 p-4 bg-white border border-[#EBEBEB] rounded-[14px] transition-all hover:border-[#1D9E75]"
            >
              <div className="w-10 h-10 rounded-full bg-[#E8F5F0] flex items-center justify-center flex-shrink-0">
                {gpsStatus === 'loading' ? (
                  <i className="ti ti-loader-2 animate-spin text-[#0F6E56] text-[18px]" />
                ) : gpsStatus === 'success' ? (
                  <i className="ti ti-check text-[#0F6E56] text-[18px]" />
                ) : (
                  <i className="ti ti-map-pin text-[#0F6E56] text-[18px]" />
                )}
              </div>
              <div className="text-left">
                <p className="text-[13px] font-medium text-[#111111]">Use my current location</p>
                {gpsStatus === 'success' && (
                  <p className="text-[11px] text-[#0F6E56] mt-0.5">Location captured ✓</p>
                )}
                {gpsStatus === 'denied' && (
                  <p className="text-[11px] text-[#9E9E9E] mt-0.5">Location access denied</p>
                )}
                {gpsStatus === 'idle' && (
                  <p className="text-[11px] text-[#9E9E9E] mt-0.5">Helps customers find you on the map</p>
                )}
              </div>
            </button>

            <PrimaryButton
              onClick={() => setStep(4)}
              disabled={!form.State || !form.LGA || (!form.Town && !customTown)}
            >
              Continue
            </PrimaryButton>
          </div>
        )}

        {/* ── STEP 4 ─────────────────────────────────────────────────────── */}
        {step === 4 && (
          <div className="space-y-4">
            <h2 className="text-[17px] font-medium text-[#111111]">Almost done — review your details</h2>

            {/* Summary card */}
            <div className="bg-white border border-[#EBEBEB] rounded-[14px] divide-y divide-[#EBEBEB]">
              {/* Personal */}
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-[12px] text-[#9E9E9E] font-medium uppercase tracking-wide">Personal</p>
                  <button onClick={() => setStep(1)} className="text-[12px] text-[#0F6E56] font-medium">Edit</button>
                </div>
                <p className="text-[14px] font-medium text-[#111111]">{form.FullName}</p>
                <p className="text-[13px] text-[#6B6B6B]">{form.Phone}</p>
                {form.WhatsApp && <p className="text-[13px] text-[#6B6B6B]">WA: {form.WhatsApp}</p>}
              </div>

              {/* Occupation */}
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-[12px] text-[#9E9E9E] font-medium uppercase tracking-wide">Occupation</p>
                  <button onClick={() => setStep(2)} className="text-[12px] text-[#0F6E56] font-medium">Edit</button>
                </div>
                <p className="text-[14px] font-medium text-[#111111]">{form.Profession}</p>
                {form.Category && <p className="text-[13px] text-[#6B6B6B]">{form.Category}</p>}
                {form.YearsExperience > 0 && (
                  <p className="text-[13px] text-[#6B6B6B]">{form.YearsExperience} years experience</p>
                )}
              </div>

              {/* Location */}
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-[12px] text-[#9E9E9E] font-medium uppercase tracking-wide">Location</p>
                  <button onClick={() => setStep(3)} className="text-[12px] text-[#0F6E56] font-medium">Edit</button>
                </div>
                <p className="text-[14px] font-medium text-[#111111]">
                  {useCustomTown ? customTown : form.Town}
                </p>
                <p className="text-[13px] text-[#6B6B6B]">{form.LGA} LGA, {form.State}</p>
                {form.Latitude && (
                  <p className="text-[12px] text-[#0F6E56] mt-0.5">GPS location captured ✓</p>
                )}
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-[8px]">
                <p className="text-[13px] text-red-600">{error}</p>
              </div>
            )}

            <PrimaryButton onClick={handleSubmit} loading={loading}>
              {loading ? 'Registering...' : 'Register on Spotly'}
            </PrimaryButton>
          </div>
        )}
      </div>
    </div>
  )
}
