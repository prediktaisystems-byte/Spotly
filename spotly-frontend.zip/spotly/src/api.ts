// All API calls go through these two functions — never raw fetch elsewhere

const API_URL = import.meta.env.VITE_API_URL as string

if (!API_URL) {
  console.error('[Spotly] VITE_API_URL is not set. Create a .env file with VITE_API_URL=your_apps_script_url')
}

export async function apiGet<T = any>(action: string, params: Record<string, any> = {}): Promise<T> {
  // Build query string — skip empty/null/undefined values
  const clean: Record<string, string> = { action }
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === '') continue
    clean[k] = String(v)
  }
  const query = new URLSearchParams(clean).toString()
  const url = `${API_URL}?${query}`
  console.log('[API GET]', action, params)
  const res = await fetch(url)
  const d = await res.json()
  if (d.status !== 'success') throw new Error(d.message || 'Request failed')
  return d.data
}

export async function apiPost<T = any>(body: Record<string, any>): Promise<T> {
  console.log('[API POST]', body.action, body)
  const res = await fetch(API_URL, {
    method: 'POST',
    body: JSON.stringify(body),
  })
  const d = await res.json()
  if (d.status !== 'success') throw new Error(d.message || 'Request failed')
  return d.data
}
