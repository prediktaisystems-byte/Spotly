import React from 'react'
import { getAvatarColor, getInitials, renderStarsArray } from '../utils'
import type { Provider } from '../types'

// ─── Skeleton card loader ──────────────────────────────────────────────────────
export function SkeletonCard() {
  return (
    <div className="bg-white border border-[#EBEBEB] rounded-[14px] p-4">
      <div className="flex gap-3 items-start">
        <div className="w-12 h-12 rounded-full bg-[#EBEBEB] animate-skeleton flex-shrink-0" />
        <div className="flex-1 space-y-2">
          <div className="h-4 bg-[#EBEBEB] rounded animate-skeleton w-3/4" />
          <div className="h-3 bg-[#EBEBEB] rounded animate-skeleton w-1/2" />
        </div>
      </div>
      <div className="mt-3 flex gap-2">
        <div className="h-6 bg-[#EBEBEB] rounded-[20px] animate-skeleton w-20" />
        <div className="h-6 bg-[#EBEBEB] rounded-[20px] animate-skeleton w-16" />
      </div>
      <div className="mt-3 h-3 bg-[#EBEBEB] rounded animate-skeleton w-1/3" />
    </div>
  )
}

// ─── Empty state ───────────────────────────────────────────────────────────────
export function EmptyState({
  icon, title, subtitle, action
}: {
  icon: string
  title: string
  subtitle?: string
  action?: { label: string; onClick: () => void }
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      <div className="w-16 h-16 rounded-full bg-[#E8F5F0] flex items-center justify-center mb-4">
        <i className={`ti ${icon} text-2xl text-[#0F6E56]`} />
      </div>
      <p className="text-[15px] font-medium text-[#111111] mb-1">{title}</p>
      {subtitle && <p className="text-[13px] text-[#6B6B6B] mb-4">{subtitle}</p>}
      {action && (
        <button
          onClick={action.onClick}
          className="px-5 py-2.5 bg-[#0F6E56] text-white text-[13px] font-medium rounded-[10px] transition-opacity hover:opacity-80"
        >
          {action.label}
        </button>
      )}
    </div>
  )
}

// ─── Error state ───────────────────────────────────────────────────────────────
export function ErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      <div className="w-16 h-16 rounded-full bg-[#E8F5F0] flex items-center justify-center mb-4">
        <i className="ti ti-wifi-off text-2xl text-[#0F6E56]" />
      </div>
      <p className="text-[15px] font-medium text-[#111111] mb-1">Connection error</p>
      <p className="text-[13px] text-[#6B6B6B] mb-4">Tap to retry</p>
      <button
        onClick={onRetry}
        className="px-5 py-2.5 bg-[#0F6E56] text-white text-[13px] font-medium rounded-[10px] transition-opacity hover:opacity-80"
      >
        Retry
      </button>
    </div>
  )
}

// ─── Stars display ─────────────────────────────────────────────────────────────
export function Stars({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <span className="flex items-center gap-0.5">
      {renderStarsArray(rating).map((filled, i) => (
        <i
          key={i}
          className={`ti ti-star${filled ? '-filled' : ''}`}
          style={{ fontSize: size, color: filled ? '#D4930A' : '#EBEBEB' }}
        />
      ))}
    </span>
  )
}

// ─── Provider card ─────────────────────────────────────────────────────────────
export function ProviderCard({
  provider,
  onClick,
}: {
  provider: Provider
  onClick: () => void
}) {
  const { bg, text } = getAvatarColor(provider.FullName)
  const initials = getInitials(provider.FullName)
  const isVerified = provider.Verified === 'true'
  const isPremium  = provider.PlanType === 'premium'
  const years      = Number(provider.YearsExperience) || 0

  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-white border border-[#EBEBEB] rounded-[14px] p-4 transition-all hover:border-[#1D9E75] hover:shadow-sm active:scale-[0.99]"
    >
      {/* Top row */}
      <div className="flex gap-3 items-start">
        <div
          className="w-12 h-12 rounded-full flex items-center justify-center text-[15px] font-medium flex-shrink-0"
          style={{ background: bg, color: text }}
        >
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[15px] font-medium text-[#111111] truncate">{provider.FullName}</p>
          <p className="text-[12px] text-[#6B6B6B] truncate">
            {provider.Profession} · {provider.Town}
          </p>
        </div>
      </div>

      {/* Badges */}
      <div className="flex flex-wrap gap-1.5 mt-2.5">
        {isVerified && (
          <span className="flex items-center gap-1 px-2 py-0.5 rounded-[20px] text-[11px] font-medium bg-[#E8F5F0] text-[#085041]">
            <i className="ti ti-circle-check" style={{ fontSize: 11 }} />
            Verified
          </span>
        )}
        {isPremium && (
          <span className="flex items-center gap-1 px-2 py-0.5 rounded-[20px] text-[11px] font-medium bg-[#FEF3DC] text-[#854F0B]">
            <i className="ti ti-crown" style={{ fontSize: 11 }} />
            Premium
          </span>
        )}
        {years > 0 && (
          <span className="flex items-center gap-1 px-2 py-0.5 rounded-[20px] text-[11px] font-medium bg-[#F1EFE8] text-[#444441]">
            <i className="ti ti-clock" style={{ fontSize: 11 }} />
            {years}yr{years !== 1 ? 's' : ''}
          </span>
        )}
        {provider.distanceLabel && provider.distanceLabel !== 'Distance unknown' && (
          <span className="flex items-center gap-1 px-2 py-0.5 rounded-[20px] text-[11px] font-medium bg-[#EBF3FD] text-[#185FA5]">
            <i className="ti ti-map-pin" style={{ fontSize: 11 }} />
            {provider.distanceLabel}
          </span>
        )}
      </div>

      {/* Bottom row */}
      {(provider.AverageRating > 0 || provider.TotalReviews > 0) && (
        <div className="flex items-center gap-1.5 mt-2.5">
          <Stars rating={provider.AverageRating} size={12} />
          <span className="text-[12px] text-[#6B6B6B]">
            {Number(provider.AverageRating).toFixed(1)} ({provider.TotalReviews} review{provider.TotalReviews !== 1 ? 's' : ''})
          </span>
        </div>
      )}
    </button>
  )
}

// ─── Section header ────────────────────────────────────────────────────────────
export function SectionHeader({ title, action }: { title: string; action?: { label: string; onClick: () => void } }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h2 className="text-[17px] font-medium text-[#111111]">{title}</h2>
      {action && (
        <button
          onClick={action.onClick}
          className="text-[13px] text-[#0F6E56] font-medium"
        >
          {action.label}
        </button>
      )}
    </div>
  )
}

// ─── Bottom sheet wrapper ──────────────────────────────────────────────────────
export function BottomSheet({
  open, onClose, children, title
}: {
  open: boolean
  onClose: () => void
  children: React.ReactNode
  title?: string
}) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      <div className="absolute inset-0 bg-black/40 animate-fadeIn" onClick={onClose} />
      <div className="relative bg-white rounded-t-[24px] animate-slideUp max-h-[85vh] overflow-y-auto">
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-[#EBEBEB]" />
        </div>
        {title && (
          <div className="px-5 pb-3 pt-1">
            <h3 className="text-[16px] font-medium text-[#111111]">{title}</h3>
          </div>
        )}
        <div className="px-5 pb-8">{children}</div>
      </div>
    </div>
  )
}

// ─── Simple select input ────────────────────────────────────────────────────────
export function SelectInput({
  value, onChange, placeholder, options, disabled
}: {
  value: string
  onChange: (v: string) => void
  placeholder: string
  options: { value: string; label: string }[]
  disabled?: boolean
}) {
  return (
    <select
      value={value}
      onChange={e => onChange(e.target.value)}
      disabled={disabled}
      className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] bg-white disabled:opacity-50 focus:outline-none focus:border-[#0F6E56]"
    >
      <option value="">{placeholder}</option>
      {options.map(o => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  )
}

// ─── Text input ─────────────────────────────────────────────────────────────────
export function TextInput({
  value, onChange, placeholder, type = 'text', required
}: {
  value: string
  onChange: (v: string) => void
  placeholder: string
  type?: string
  required?: boolean
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      required={required}
      className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] bg-white focus:outline-none focus:border-[#0F6E56] placeholder:text-[#9E9E9E]"
    />
  )
}

// ─── Primary button ─────────────────────────────────────────────────────────────
export function PrimaryButton({
  onClick, children, loading, disabled, className = ''
}: {
  onClick?: () => void
  children: React.ReactNode
  loading?: boolean
  disabled?: boolean
  className?: string
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={`w-full h-[52px] bg-[#0F6E56] text-white text-[15px] font-medium rounded-[10px] flex items-center justify-center gap-2 transition-opacity hover:opacity-90 disabled:opacity-50 ${className}`}
    >
      {loading && <i className="ti ti-loader-2 animate-spin text-[18px]" />}
      {children}
    </button>
  )
}
