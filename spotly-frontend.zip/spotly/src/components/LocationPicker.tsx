import React, { useState, useEffect } from 'react'
import { apiGet } from '../api'
import { saveLocation } from '../utils'
import { BottomSheet, SelectInput, PrimaryButton } from './UI'
import type { StateItem, LgaItem, TownItem, LocationData } from '../types'

interface Props {
  open: boolean
  onClose: () => void
  onConfirm: (loc: LocationData) => void
  initial?: LocationData
}

export default function LocationPicker({ open, onClose, onConfirm, initial }: Props) {
  const [states, setStates]   = useState<StateItem[]>([])
  const [lgas,   setLgas]     = useState<LgaItem[]>([])
  const [towns,  setTowns]    = useState<TownItem[]>([])

  const [selState, setSelState] = useState(initial?.state || '')
  const [selLga,   setSelLga]   = useState(initial?.lga   || '')
  const [selTown,  setSelTown]  = useState(initial?.town  || '')
  const [customTown, setCustomTown] = useState('')
  const [useCustom, setUseCustom]   = useState(false)
  const [provCount, setProvCount]   = useState<number | null>(null)

  // Load states on open
  useEffect(() => {
    if (!open) return
    apiGet<StateItem[]>('getStates').then(setStates).catch(() => {})
  }, [open])

  // Load LGAs when state changes
  useEffect(() => {
    if (!selState) { setLgas([]); setSelLga(''); return }
    apiGet<LgaItem[]>('getLgasByState', { state: selState }).then(setLgas).catch(() => {})
    setSelLga('')
    setSelTown('')
    setTowns([])
  }, [selState])

  // Load towns when LGA changes
  useEffect(() => {
    if (!selLga) { setTowns([]); setSelTown(''); return }
    apiGet<TownItem[]>('getTownsByLga', { lga: selLga, state: selState }).then(setTowns).catch(() => {})
    setSelTown('')
    // Get provider count for this LGA
    apiGet<any>('getOccupationCountsByLocation', { lga: selLga, state: selState })
      .then(d => setProvCount(d.totalProviders))
      .catch(() => setProvCount(null))
  }, [selLga])

  function handleConfirm() {
    const town = useCustom ? customTown : selTown
    if (!selState || !selLga || !town) return
    saveLocation(town, selLga, selState)
    onConfirm({ town, lga: selLga, state: selState })
    onClose()
  }

  const canConfirm = selState && selLga && (useCustom ? customTown : selTown)

  return (
    <BottomSheet open={open} onClose={onClose} title="Choose your location">
      <div className="space-y-3">
        <SelectInput
          value={selState}
          onChange={setSelState}
          placeholder="Select state"
          options={states.map(s => ({ value: s.state, label: s.state }))}
        />

        {selState && (
          <SelectInput
            value={selLga}
            onChange={setSelLga}
            placeholder="Select LGA"
            options={lgas.map(l => ({ value: l.lga, label: l.lga }))}
          />
        )}

        {selLga && !useCustom && (
          <SelectInput
            value={selTown}
            onChange={setSelTown}
            placeholder="Select town"
            options={towns.map(t => ({ value: t.town, label: t.town }))}
          />
        )}

        {selLga && useCustom && (
          <input
            type="text"
            value={customTown}
            onChange={e => setCustomTown(e.target.value)}
            placeholder="Type your town name"
            className="w-full h-11 px-3 border border-[#EBEBEB] rounded-[8px] text-[13px] text-[#111111] bg-white focus:outline-none focus:border-[#0F6E56] placeholder:text-[#9E9E9E]"
          />
        )}

        {selLga && (
          <label className="flex items-center gap-2 text-[13px] text-[#6B6B6B] cursor-pointer">
            <input
              type="checkbox"
              checked={useCustom}
              onChange={e => setUseCustom(e.target.checked)}
              className="w-4 h-4 accent-[#0F6E56]"
            />
            My town isn't listed
          </label>
        )}

        {provCount !== null && selLga && (
          <p className="text-[12px] text-[#0F6E56] font-medium">
            {provCount} provider{provCount !== 1 ? 's' : ''} in {selLga} LGA
          </p>
        )}

        <PrimaryButton onClick={handleConfirm} disabled={!canConfirm}>
          Confirm location
        </PrimaryButton>
      </div>
    </BottomSheet>
  )
}
