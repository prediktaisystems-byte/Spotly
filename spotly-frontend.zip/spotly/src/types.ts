export type View = 'home' | 'search' | 'nearby' | 'register' | 'about' | 'profile'

export interface Provider {
  ProviderId: string
  FullName: string
  BusinessName?: string
  Profession: string
  Category: string
  Phone: string
  WhatsApp?: string
  Town: string
  LGA: string
  State: string
  YearsExperience: number
  Bio?: string
  PortfolioUrls: string[]
  Verified: string
  PlanType: string
  Featured: string
  DateRegistered: string
  Status: string
  AverageRating: number
  TotalReviews: number
  Latitude?: string
  Longitude?: string
  distanceKm?: number | null
  distanceLabel?: string
  distanceSource?: string
}

export interface Category {
  CategoryId: string
  CategoryName: string
  Icon: string
  Description: string
  TotalProviders: number
}

export interface StateItem {
  state: string
  totalProviders: number
}

export interface LgaItem {
  lga: string
  state: string
  totalProviders: number
}

export interface TownItem {
  town: string
  lga: string
  state: string
  totalProviders: number
}

export interface Review {
  ReviewId: string
  ProviderId: string
  ReviewerName: string
  Rating: number
  ReviewText: string
  DateSubmitted: string
  Status: string
}

export interface DashboardStats {
  totalProviders: number
  premiumProviders: number
  totalAgents: number
  totalReviews: number
  pendingReviews: number
  totalInquiries: number
  newInquiries: number
  activePremiumListings: number
  totalCommissionsPaid: number
  providersByTown: Record<string, number>
  providersByCategory: Record<string, number>
}

export interface LocationData {
  town: string
  lga: string
  state: string
}
