// ─── Avatar colors ────────────────────────────────────────────────────────────
const AVATAR_COLORS = [
  { bg: '#E8F5F0', text: '#085041' },
  { bg: '#EBF3FD', text: '#0C447C' },
  { bg: '#FAECE7', text: '#712B13' },
  { bg: '#FAEEDA', text: '#633806' },
  { bg: '#EEEDFE', text: '#3C3489' },
  { bg: '#FBEAF0', text: '#72243E' },
]

export function getAvatarColor(name: string) {
  const code = name.charCodeAt(0) || 0
  return AVATAR_COLORS[code % 6]
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(w => w[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase()
}

// ─── WhatsApp link formatter ───────────────────────────────────────────────────
export function formatWhatsApp(phone: string, name: string): string {
  let c = phone.replace(/\D/g, '')
  if (c.startsWith('0')) c = '234' + c.slice(1)
  if (!c.startsWith('234')) c = '234' + c
  const msg = encodeURIComponent(
    `Hi ${name}, I found you on Spotly and would like to enquire about your services.`
  )
  return `https://wa.me/${c}?text=${msg}`
}

// ─── Distance label fallback ───────────────────────────────────────────────────
export function formatDistance(km: number | null | undefined): string {
  if (km == null) return ''
  if (km < 1) return Math.round(km * 1000) + 'm away'
  if (km < 10) return km.toFixed(1) + 'km away'
  return Math.round(km) + 'km away'
}

// ─── Star rating renderer ──────────────────────────────────────────────────────
export function renderStarsArray(rating: number): boolean[] {
  return Array.from({ length: 5 }, (_, i) => i < Math.round(rating))
}

// ─── Location localStorage helpers ────────────────────────────────────────────
export function saveLocation(town: string, lga: string, state: string) {
  localStorage.setItem('spotly_town', town)
  localStorage.setItem('spotly_lga', lga)
  localStorage.setItem('spotly_state', state)
}

export function getSavedLocation(): { town: string; lga: string; state: string } {
  return {
    town:  localStorage.getItem('spotly_town')  || '',
    lga:   localStorage.getItem('spotly_lga')   || '',
    state: localStorage.getItem('spotly_state') || '',
  }
}

// ─── Relative date ─────────────────────────────────────────────────────────────
export function relativeDate(iso: string): string {
  const d = new Date(iso)
  const now = new Date()
  const days = Math.floor((now.getTime() - d.getTime()) / 86400000)
  if (days === 0) return 'Today'
  if (days === 1) return 'Yesterday'
  if (days < 30) return `${days}d ago`
  if (days < 365) return `${Math.floor(days / 30)}mo ago`
  return `${Math.floor(days / 365)}y ago`
}
