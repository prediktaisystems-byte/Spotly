# Spotly Frontend

Local business and skilled worker discovery platform — React + Tailwind CSS.

## Setup

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/spotly-frontend.git
cd spotly-frontend

# 2. Install dependencies
npm install

# 3. Create environment file
cp .env.example .env

# 4. Add your Apps Script URL to .env
# Open .env and set:
# VITE_API_URL=https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec

# 5. Start dev server
npm run dev
```

## Deploy to Netlify (recommended — no CORS issues)

1. Push this repo to GitHub
2. Go to netlify.com → New site from Git → connect your repo
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Add environment variable: `VITE_API_URL` = your Apps Script URL
6. Deploy

## Deploy to Vercel

1. Push to GitHub
2. Import project on vercel.com
3. Add `VITE_API_URL` in environment variables
4. Deploy

## Project Structure

```
src/
  api.ts              — apiGet and apiPost wrappers (all API calls go here)
  types.ts            — TypeScript types
  utils.ts            — Helper functions (avatar, WhatsApp, distance, stars)
  App.tsx             — Main app, routing, bottom nav
  views/
    HomeView.tsx      — Homepage with hero, categories, featured providers
    SearchView.tsx    — Search with filters and category chips
    NearbyView.tsx    — GPS-based nearby providers
    RegisterView.tsx  — 4-step provider registration form
    AboutView.tsx     — About page with live stats
    ProfileView.tsx   — Provider profile with tabs, reviews, portfolio
  components/
    UI.tsx            — Shared components (cards, buttons, inputs, skeletons)
    LocationPicker.tsx — Location selection bottom sheet
```

## Environment Variables

| Variable | Description |
|---|---|
| `VITE_API_URL` | Your Google Apps Script deployment URL |

## Features

- 5 views: Home, Search, Nearby, Register, About
- Provider profile with Info / Portfolio / Reviews tabs
- 4-step registration form with GPS capture
- Location picker with State → LGA → Town cascade
- GPS-based nearby providers with radius filter
- Category chips and advanced filters
- Portfolio image upload and delete
- Review submission
- WhatsApp and phone call integration
- Skeleton loading states
- Empty and error states with retry
- Mobile-first, iOS safe area support
