/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary:    '#0F6E56',
        'mid-green':'#1D9E75',
        'light-green':'#E8F5F0',
        'pale-tint': '#F2FAF7',
        'page-bg':  '#F7F6F3',
        surface:    '#FFFFFF',
        'text-primary': '#111111',
        'text-secondary':'#6B6B6B',
        'text-tertiary': '#9E9E9E',
        border:     '#EBEBEB',
        amber:      '#D4930A',
      },
      borderRadius: {
        card: '14px',
        btn:  '10px',
        inp:  '8px',
        badge:'20px',
      },
      fontFamily: {
        sans: ['-apple-system','BlinkMacSystemFont','Segoe UI','sans-serif'],
      },
      transitionDuration: { DEFAULT: '150ms' },
      keyframes: {
        pulse2: {
          '0%,100%': { opacity: '0.4' },
          '50%':     { opacity: '0.8' },
        },
        slideUp: {
          from: { transform: 'translateY(100%)' },
          to:   { transform: 'translateY(0)' },
        },
        fadeIn: {
          from: { opacity: '0' },
          to:   { opacity: '1' },
        },
      },
      animation: {
        skeleton: 'pulse2 1.2s ease infinite',
        slideUp:  'slideUp 0.28s ease',
        fadeIn:   'fadeIn 0.2s ease',
      },
    },
  },
  plugins: [],
}
